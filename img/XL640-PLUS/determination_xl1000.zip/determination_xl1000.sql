/*
Navicat MySQL Data Transfer

Source Server         : SERVER 172.16.0.20 
Source Server Version : 50505
Source Host           : 172.16.0.20:3306
Source Database       : loginslab

Target Server Type    : MYSQL
Target Server Version : 50505
File Encoding         : 65001

Date: 2025-05-26 17:00:42
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `determination_xl1000`
-- ----------------------------
DROP TABLE IF EXISTS `determination_xl1000`;
CREATE TABLE `determination_xl1000` (
  `DeterID` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `DeterName` varchar(45) NOT NULL,
  `detercode` varchar(45) DEFAULT NULL,
  `DeterMin` float NOT NULL,
  `DeterMax` float NOT NULL,
  `DeterOperate` varchar(1) NOT NULL,
  `DeterUnit` varchar(45) NOT NULL,
  `hositemcode` varchar(150) NOT NULL,
  `enable` tinyint(1) NOT NULL,
  `deterpoint` int(10) unsigned DEFAULT 0,
  `DeterSpecial` varchar(255) DEFAULT NULL,
  `DeterFactor` int(11) DEFAULT NULL,
  `job_instruments_id` int(11) DEFAULT NULL,
  `serum_name` varchar(20) DEFAULT NULL,
  `lab_specimen_id` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`DeterID`),
  KEY `ix_job_instruments_id` (`job_instruments_id`) USING BTREE,
  KEY `ix_lab_specimen_id` (`lab_specimen_id`) USING BTREE
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=tis620 COLLATE=tis620_thai_ci;

-- ----------------------------
-- Records of determination_xl1000
-- ----------------------------
INSERT INTO `determination_xl1000` VALUES ('1', 'GLUC', 'GLUC', '3.8', '5.5', 'B', 'g/dl', '80,115', '1', '0', null, null, '26', null, '6,23');
INSERT INTO `determination_xl1000` VALUES ('2', 'BUN1', 'BUN1', '40', '129', 'B', 'U/L', '81', '1', '0', null, null, '26', null, null);
INSERT INTO `determination_xl1000` VALUES ('3', 'CREJ', 'CREJ', '8', '53', 'B', 'U/L', '82', '1', '2', null, null, '26', null, null);
INSERT INTO `determination_xl1000` VALUES ('4', 'CHO', 'CHO', '0', '0.2', 'B', 'mg/dl', '84', '1', '0', null, null, '26', null, null);
INSERT INTO `determination_xl1000` VALUES ('5', 'ALB1', 'ALB1', '0', '6', 'B', 'mg/dl', '93', '1', '1', null, null, '26', null, null);
INSERT INTO `determination_xl1000` VALUES ('6', 'UA1', 'UA1', '8.4', '10.3', 'B', 'mEq/L', '0', '1', '1', null, null, '26', null, null);
INSERT INTO `determination_xl1000` VALUES ('7', 'PROT', 'PROT', '98', '106', 'B', 'mEq/L', '0', '1', '1', null, null, '26', null, null);
INSERT INTO `determination_xl1000` VALUES ('8', 'HDL', 'HDL', '0', '200', 'L', 'mg/dl', '86', '1', '0', null, null, '26', null, null);
INSERT INTO `determination_xl1000` VALUES ('9', 'TG1', 'TG1', '0', '200', 'B', 'U/L', '0', '1', '0', null, null, '26', null, null);
INSERT INTO `determination_xl1000` VALUES ('10', 'GOT', 'GOT ', '15', '200', 'B', 'U/L', '0', '0', '0', null, null, '26', null, null);
INSERT INTO `determination_xl1000` VALUES ('11', 'GPT', 'GPT', '0.5', '2', 'B', 'mg/dl', '0', '0', '0', null, null, '26', null, null);
INSERT INTO `determination_xl1000` VALUES ('12', 'ALK', 'ALK', '8', '32', 'B', 'mg/dl', '672', '1', '0', null, null, '26', null, null);
INSERT INTO `determination_xl1000` VALUES ('13', 'AST1', 'AST1', '50', '80', 'B', 'mg/dl', '90', '1', '0', null, null, '26', null, null);
INSERT INTO `determination_xl1000` VALUES ('14', 'ALT1', 'ALT1', '4.3', '5.8', 'B', '%', '91', '1', '0', null, null, '26', null, null);
INSERT INTO `determination_xl1000` VALUES ('15', 'LDH', 'LDH ', '35', '65', 'B', 'mg/dl', '0', '0', '0', null, null, '26', null, null);
INSERT INTO `determination_xl1000` VALUES ('16', 'LDLD', 'LDLD', '113', '246', 'B', 'U/L', '87', '1', '0', null, null, '26', null, null);
INSERT INTO `determination_xl1000` VALUES ('17', 'BILT', 'BILT', '0', '150', 'L', 'mg/dl', '0', '1', '2', null, null, '26', null, null);
INSERT INTO `determination_xl1000` VALUES ('18', 'BILD1', 'BILD1', '3', '4', 'B', 'mg/dl', '0', '1', '2', null, null, '26', null, null);
INSERT INTO `determination_xl1000` VALUES ('19', 'URIC', 'URIC', '3.6', '5.5', 'B', 'mEq/L', '83', '0', '1', null, null, '26', null, null);
INSERT INTO `determination_xl1000` VALUES ('21', 'Na', 'Na', '0', '0', '', '', '0', '0', '2', null, null, '26', null, null);
INSERT INTO `determination_xl1000` VALUES ('22', 'K', 'K', '0', '0', '', '', '0', '0', '2', null, null, '26', null, null);
INSERT INTO `determination_xl1000` VALUES ('23', 'Cl', 'Cl', '0', '0', '', '', '0', '0', '2', null, null, '26', null, null);
INSERT INTO `determination_xl1000` VALUES ('24', 'Sl', 'Sl', '0', '0', '', '', '0', '0', '0', null, null, '26', null, null);
INSERT INTO `determination_xl1000` VALUES ('25', 'HBA1C', 'HBA1C', '0', '0', '', '', '0', '1', '1', null, null, '26', 'BLOOD', '23');
INSERT INTO `determination_xl1000` VALUES ('27', 'TP', 'TP', '0', '0', '', '', '92', '1', '1', null, null, '26', null, null);
INSERT INTO `determination_xl1000` VALUES ('26', 'TRI', 'TRI', '0', '0', '', '', '85', '0', '0', null, null, '26', null, null);
INSERT INTO `determination_xl1000` VALUES ('28', 'TBI', 'TBI', '0', '0', '', '', '88', '0', '2', null, null, '26', null, null);
INSERT INTO `determination_xl1000` VALUES ('29', 'DBI', 'DBI', '0', '0', '', '', '89', '0', '2', null, null, '26', null, null);
INSERT INTO `determination_xl1000` VALUES ('30', 'SI-I', 'SI-I', '0', '0', '', '', '0', '0', '0', null, null, '26', null, null);
INSERT INTO `determination_xl1000` VALUES ('31', 'GLOB', 'GLOB', '0', '0', '', '', '0', '0', '0', null, null, '26', null, null);
INSERT INTO `determination_xl1000` VALUES ('33', 'CAL', 'CAL', '0', '0', '', '', '106', '0', null, null, null, '26', null, null);
INSERT INTO `determination_xl1000` VALUES ('34', 'MG', 'MG', '0', '0', '', '', '108', '0', null, null, null, '26', null, null);
INSERT INTO `determination_xl1000` VALUES ('35', 'P', 'P', '0', '0', '', '', '107', '0', null, null, null, '26', null, null);
